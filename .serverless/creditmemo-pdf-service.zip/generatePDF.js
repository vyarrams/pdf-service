const PDFToolsSdk = require('@adobe/pdfservices-node-sdk');
const fs = require('fs')
const inputFile = "./creditMemo.docx"
const outputFile = "/tmp/creditMemo.pdf"

const generatePDF = async (creditMemoJson) => {
    if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);

    const credentials = PDFToolsSdk.Credentials
        .serviceAccountCredentialsBuilder()
        .fromFile("./pdfservices-api-credentials.json")
        .build();

    const executionContext = PDFToolsSdk.ExecutionContext.create(credentials)

    const documentMerge = PDFToolsSdk.DocumentMerge,
        documentMergeOptions = documentMerge.options,
        options = new documentMergeOptions.DocumentMergeOptions(creditMemoJson, documentMergeOptions.OutputFormat.PDF)

    const documentMergeOperation = documentMerge.Operation.createNew(options)

    const input = PDFToolsSdk.FileRef.createFromLocalFile(inputFile)
    documentMergeOperation.setInput(input)

    let result = await documentMergeOperation.execute(executionContext);
    await result.saveAsFile(outputFile);
};


module.exports = {
    generatePDF,
    outputFile
};
