const express = require('express');
const cors = require("cors");

const app = express();
app.use(cors({ origin: '*' }));
app.use(cors({ credentials: true }));
app.options("*", cors());
const fs = require('fs');


const {
    generatePDF, outputFile
} = require('./generatePDF');

app.use(express.json());

app.get('/', (req, res) => {
    res.send('This is eProLend-CreditMemo PDF Generation API');
});

app.post('/generatePDF', async (req, res) => {
    const creditMemoJson = req.body;
    try {
        await generatePDF(creditMemoJson);
        // if (outputFile && fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
        var data = fs.readFileSync(outputFile);



        // var file = fs.createReadStream(outputFile);
        // var stat = fs.statSync(outputFile);
        res.set('Access-Control-Allow-Origin', '*');
        res.set('Access-Control-Allow-Headers', '*');
        res.set('Access-Control-Allow-Methods', '*');
        res.set('Access-Control-Allow-Credentials', true);
        // res.set('Content-Length', stat.size);
        res.set('Content-Type', 'application/pdf');
        // res.set('Content-Disposition', 'attachment; filename=creditMemo.pdf');
        // res.set('Content-Disposition', 'inline');
        // file.pipe(res);
        res.end(data, 'base64')
    } catch (err) {
        console.error(err);
        res.status(500).json({ err: 'Something went wrong: ' + err });
    }
});

// const port = process.env.PORT || 3000;
// app.listen(port, () => {
//     console.log(`listening on port: ` + port);
// });
module.exports = app;